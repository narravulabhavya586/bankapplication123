package login.bank.register;

public interface MyPovider {
	String USER = "bhavya";
    String PASS = "bhavya@586";
    String DB_URL ="jdbc:mysql://localhost:3306/covid19";

}
