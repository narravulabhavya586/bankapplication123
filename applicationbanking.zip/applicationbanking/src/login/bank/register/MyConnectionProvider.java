package login.bank.register;
import java.sql.*;

public class MyConnectionProvider implements MyPovider {
	static Connection con=null;
	public static Connection getCon(){
		try{
			class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(DB_URL,USER, PASS);
		}catch(Exception e){
			System.out.println(e);	
		}
		return con;	
	}
}
