package login.bank.register;

public interface CustomerDoa {
	
	public int insertCustomer(Customer c);
	public  Customer getCustomer(String username,String pass);
	

}
